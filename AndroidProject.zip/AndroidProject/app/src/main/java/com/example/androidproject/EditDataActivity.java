package com.example.androidproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditDataActivity extends AppCompatActivity {
private static final String TAG = "EditDataActivity";
private Button btnSave,btnDelete;
private EditText editable_item;
DatabaseHelper mDatabaseHelper;
private String selectedName;
private int selectedId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);
        btnSave = findViewById(R.id.btnSave);
        btnDelete = findViewById(R.id.btnDelete);
        editable_item = findViewById(R.id.edittable_item);
        mDatabaseHelper = new DatabaseHelper(this);
        //get the intent extra from the ListDataActivity
        Intent receivedIntent = getIntent();
        //now get the itemid we passed as an extra
        selectedId = receivedIntent.getIntExtra("id",-1);
        //now get the name we passed as an extra
        selectedName = receivedIntent.getStringExtra("name");
        //set the text to show the current selected name
        editable_item.setText(selectedName);
        btnSave.setOnClickListener(new View.OnClickListener() {
       @Override
               public void onClick(View view) {
        String item = editable_item.getText().toString();
        if(!item.equals("")){
    mDatabaseHelper.updateName(item,selectedId,selectedName);
       }else{
    toastMessage("YOU MUST ENTER A NAME");
     }
    }
});
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteName(selectedId,selectedName);
                editable_item.setText("");
                toastMessage("removed from database");
            }
        });

    }
    private void toastMessage(String message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
