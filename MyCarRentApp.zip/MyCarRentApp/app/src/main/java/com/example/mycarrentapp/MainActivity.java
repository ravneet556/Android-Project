package com.example.mycarrentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    String carMake[] = {"NISSAN","FORD","TOYOTA","HONDA"};
    ArrayList <car> cars = new ArrayList<car>();
    ArrayList <String> SelectedMake = new ArrayList<String>();
    CheckBox cb[] = new CheckBox[4];
    ImageView img;
    Spinner make,type;
    public void setCarDetails(){
        cars.add(new car("ABC 123","FORD","Escape",2019,40,0.7,2340,new int[]{1,0,0,1}));
        cars.add(new car("ABC 123","FORD","Edge",2020,50,0.4,1340,new int[]{1,1,0,1}));
        cars.add(new car("ABC 123","FORD","Focus",2019,60,0.5,3340,new int[]{1,0,1,1}));
        cars.add(new car("ABC 123","FORD","Explorer",2020,70,0.6,4340,new int[]{0,0,0,1}));
        cars.add(new car("ABC 123","NISSAN","Rogue",2019,40,0.3,2440,new int[]{1,0,0,0}));
        cars.add(new car("ABC 123","NISSAN","Sunny",2019,50,0.8,2540,new int[]{1,0,0,0}));
        cars.add(new car("ABC 123","NISSAN","Tida",2020,60,0.2,2640,new int[]{1,0,1,1}));
        cars.add(new car("ABC 123","NISSAN","Altima",2019,70,0.7,2740,new int[]{1,1,1,1}));
        cars.add(new car("ABC 123","TOYOTA","Corolla",2019,40,0.7,2380,new int[]{1,0,0,1}));
        cars.add(new car("ABC 123","TOYOTA","Camry",2020,40,0.4,2360,new int[]{0,0,0,0}));
        cars.add(new car("ABC 123","HONDA","Civic",2019,50,0.3,2380,new int[]{1,0,0,0}));
        cars.add(new car("ABC 123","HONDA","Accord",2020,60,0.1,2320,new int[]{1,0,1,1}));

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setCarDetails();
        make = findViewById(R.id.spMake);
        type = findViewById(R.id.spType);
        img = findViewById(R.id.img);
        cb[0] = findViewById(R.id.cbNav);
        cb[1] = findViewById(R.id.cbCam);
        cb[2] = findViewById(R.id.cbSun);
        cb[3] = findViewById(R.id.cbSma);
        make.setOnItemSelectedListener(this);
        type.setOnItemSelectedListener(this);
        ArrayAdapter makeAdap = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,carMake);
        makeAdap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        make.setAdapter(makeAdap);
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.spMake){
            SelectedMake.clear();
            for(int j =0;j<cars.size();j++) {
                if (cars.get(j).getMake().equals(carMake[i]))
                    SelectedMake.add(cars.get(j).getType());
                
            }
                ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,SelectedMake);
                aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                type.setAdapter(aa);
        }
        else if(adapterView.getId()==R.id.spType){
                int index=searchCars(SelectedMake.get(i));
                chkBoxes(index);
                String imgName = cars.get(index).getType().toLowerCase();
                int imgId=getResources().getIdentifier(imgName,"drawable",getPackageName());
                img.setImageResource(imgId);



        }

    }
        public void chkBoxes(int index){
        int i = index;
        for(int j=0;j<4;j++)
        if(cars.get(i).getOptions()[j]==1)
            cb[j].setChecked(true);
        else
            cb[j].setChecked(false);

    }
        public int searchCars(String carType){
            for(int i=0;i<cars.size();i++)
                if(cars.get(i).getType().equals(carType))
                    return i;
            return -1;
        }


        @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
