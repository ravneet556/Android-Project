package com.example.mycarrentapp;

public class car {
    private String plateno;
    private String make;
    private String type;
    private int year;
    private double rate;
    private double extracharges;
    private int millage;
    private int[] options = new int[4];

    public car(String plateno, String make, String type, int year, double rate, double extracharges, int millage, int[] options) {
        this.plateno = plateno;
        this.make = make;
        this.type = type;
        this.year = year;
        this.rate = rate;
        this.extracharges = extracharges;
        this.millage = millage;
        this.options = options;
    }

    public String getPlateno() {
        return plateno;
    }

    public String getMake() {
        return make;
    }

    public String getType() {
        return type;
    }

    public int getYear() {
        return year;
    }

    public double getRate() {
        return rate;
    }

    public double getExtracharges() {
        return extracharges;
    }

    public int getMillage() {
        return millage;
    }

    public int[] getOptions() {
        return options;
    }

    public void setPlateno(String plateno) {
        this.plateno = plateno;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public void setExtracharges(double extracharges) {
        this.extracharges = extracharges;
    }

    public void setMillage(int millage) {
        this.millage = millage;
    }

    public void setOptions(int[] options) {
        this.options = options;
    }
}
