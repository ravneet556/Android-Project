package com.example.shoppingapplistspinner;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProductDetails extends AppCompatActivity {
    ImageView iv;
    TextView name,prices;

    @Override
    protected void onCreate(Bundle savedInstancesState) {

        super.onCreate(savedInstancesState);
       setContentView(R.layout.product_details);
       name = findViewById(R.id.txtN);
       prices = findViewById(R.id.txtP);
       name.setText(MainActivity.name);
       prices.setText(String.format("%.2f",MainActivity.price));
       iv=findViewById(R.id.img2);
       iv.setImageResource(MainActivity.img);

    }}

