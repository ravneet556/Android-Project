package com.example.shoppingapplistspinner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  implements AdapterView.OnItemClickListener,AdapterView.OnItemSelectedListener {
ListView productList;
ArrayList<Product> products = new ArrayList<Product>();
    ArrayList<Product> selected = new ArrayList<Product>();
public static String name;
public static double price;
public static int img;
Spinner spin;
String[] type ={"iphone","Watch","phone"};


    public void fillProducts(){
        products.add(new Product("Apple watch",1230,"Watch",R.drawable.apple));
        products.add(new Product("Fossil watch",850,"Watch",R.drawable.fossil));
        products.add(new Product("Garmin watch",670,"Watch",R.drawable.garmin));
        products.add(new Product("Samsung watch",500,"Watch",R.drawable.samsung));
        products.add(new Product("iPhone 11",1500,"iphone",R.drawable.iphone));
        products.add(new Product("Galaxy 10",1300,"phone",R.drawable.galaxy));



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillProducts();
        productList = findViewById(R.id.lvProducts);
        productList.setAdapter(new ProductAdapter(this,products));
        productList.setOnItemClickListener(this);
        spin = findViewById(R.id.sp);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,type);
        aa.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spin.setAdapter(aa);
        spin.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
name = products.get(i).getProductName();
price = products.get(i).getProductPrice();
img = products.get(i).getProductImage();
        Intent intent = new Intent(this,ProductDetails.class); //to link pages
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String typeName = type[i];
        selected.clear();
        for(int j=0;j<products.size();j++)
            if(typeName.equals(products.get(j).getProductType()))
                selected.add(products.get(j));
            productList.setAdapter(new ProductAdapter(this,selected));

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
