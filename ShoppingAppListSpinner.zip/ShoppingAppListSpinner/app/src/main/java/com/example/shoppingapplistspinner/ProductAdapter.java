package com.example.shoppingapplistspinner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ProductAdapter  extends BaseAdapter {
private ArrayList<Product>  ProductDetails; //array list
    LayoutInflater layoutInflater ; //to link layout list_row

  public ProductAdapter(Context context,ArrayList<Product> ProductDetails){
      this.ProductDetails = ProductDetails;
      layoutInflater = LayoutInflater.from(context);
  }



    @Override
    public int getCount() {
        return ProductDetails.size();
    }

    @Override
    public Object getItem(int i) {
        return ProductDetails.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
      ViewHolder holder;
      if(view == null){
          holder = new ViewHolder();
          view = layoutInflater.inflate(R.layout.list_row,null);
          holder.tvName=view.findViewById(R.id.txtName);
          holder.tvPrice=view.findViewById(R.id.txtPrice);
          holder.productImage=view.findViewById(R.id.img);
          view.setTag(holder);

      }
      else
          holder = (ViewHolder) view.getTag();
      holder.tvPrice.setText(String.format("%.2f",ProductDetails.get(i).getProductPrice()));
        holder.tvName.setText(ProductDetails.get(i).getProductName());
        holder.productImage.setImageResource(ProductDetails.get(i).getProductImage());
        return view;
  }
      static class ViewHolder{
          TextView tvName, tvPrice;
          ImageView productImage;
      }
    }

