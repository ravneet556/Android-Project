package com.example.shoppingapplistspinner;

public class Product {
    private String productName;
    private double productPrice;
    private String productType;
    private int ProductImage;

    public Product(String productName, double productPrice, String productType, int productImage) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productType = productType;
        ProductImage = productImage;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public String getProductType() {
        return productType;
    }

    public int getProductImage() {
        return ProductImage;
    }
}
